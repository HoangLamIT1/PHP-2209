<?php
    session_start();
    $connect = new mysqli("localhost","dhl","dhl","dhl") or die("ERROR CONFIG");
?>