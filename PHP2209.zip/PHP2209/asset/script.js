let load = document.getElementById('load');
let countDot = 20;

window.onload = function(){
    load.style.display = 'none';
}