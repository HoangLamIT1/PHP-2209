<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="./style.css">  
</head>
<body>
    <div class="center">
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
    </div>
    <script src="script.js"></script>
</body>
</html>