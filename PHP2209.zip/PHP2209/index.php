<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP BEGINNER</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <script src="import/sidebar.js"></script>
    <link rel="stylesheet" href="import/style.css">
</head>
<body>
    <?php
        include 'asset/sidebar.php';
    ?>
    <div class = "continer mt-3">
        <div class = "card" style = "width:400px">
            <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/img_avatar1.png" alt="Card image" style="width:100%">
            <div class = "card-body">
                <h4 class = "card-title">Do Hoang Lam</h4>
                <p class="card-text">I'm Admin HoangLamIT.com</p>
                <p class="card-text">I'm from Vietnam and I am a Developer</p>
                <a href="https://www.facebook.com/DoHoangLam.X.Developer" class="btn btn-primary" target = "_blank">Contact For Work</a>
            </div>
        </div>
    </div>
    <br><footer>
        <?php
            include 'asset/footer.php'
        ?>
    </footer>
</body>
</html>