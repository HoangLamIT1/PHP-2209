<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
    <div id="wrapper" class = "footer">
        <div class="overlay"></div>
        <nav class="navbar navbar-inverse fixed-top" id="sidebar-wrapper" role="navigation">
            <ul class="nav sidebar-nav">
            <div class="sidebar-header">
            <div class="sidebar-brand">
                <a href="#">HoangLamIT</a></div></div>
            <li><a href="#">Home</a></li>
            <li><a href="/about-me">About</a></li>
            <li><a href="https://www.facebook.com/DoHoangLam.X.Developer">Follow me</a></li>
            </ul>
        </nav>
        <div id="page-content-wrapper">
            <button type="button" class="hamburger animated fadeInLeft is-closed" data-toggle="offcanvas">
                <span class="hamb-top"></span>
                <span class="hamb-middle"></span>
                <span class="hamb-bottom"></span>
            </button>
            <div class="container">
                <div class="row"></div>
            </div>
        </div>
    </div>
</body>
</html>